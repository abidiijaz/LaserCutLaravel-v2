<?php
    $diameters=$focal_lengths=$powerModels=$voltages=$set_words=$sizes=$working_areas=$bone_diameterss=$models=$output_voltages=$model_numbers=$types=$calibers=$sub_strate_sizes=$wavelengths=$materials=$styles=$colors= array();

    if($product->diameter != null){
        $diameters = explode (",", $product->diameter);
    }
    if($product->focal_length != null){
        $focal_lengths = explode (",", $product->focal_length);
    }
    if($product->power_model != null){
        $powerModels = explode (",", $product->power_model);
    }
    if($product->voltage != null){
        $voltages = explode (",", $product->voltage);
    }
    if($product->set_word != null){
        $set_words = explode (",", $product->set_word);
    }
    if($product->size != null){
        $sizes = explode (",", $product->size);
    }
    if($product->working_area != null){
        $working_areas = explode (",", $product->working_area);
    }
    if($product->bone_diameters != null){
        $bone_diameterss = explode (",", $product->bone_diameters);
    }
    if($product->model != null){
        $models = explode (",", $product->model);
    }
    if($product->output_voltage != null){
        $output_voltages = explode (",", $product->output_voltage);
    }
    if($product->model_number != null){
        $model_numbers = explode (",", $product->model_number);
    }
    if($product->type != null){
        $types = explode (",", $product->type);
    }
    if($product->caliber != null){
        $calibers = explode (",", $product->caliber);
    }
    if($product->sub_strate_size != null){
        $sub_strate_sizes = explode (",", $product->sub_strate_size);
    }
    if($product->wavelength != null){
        $wavelengths = explode (",", $product->wavelength);
    }
    if($product->material != null){
        $materials = explode (",", $product->material);
    }
    if($product->style != null){
        $styles = explode (",", $product->style);
    }
    if($product->color != null){
        $colors = explode (",", $product->color);
    }
    // print_r($set_words);
?>
<!-- For Diameter Checkout -->
 <?php if(count($diameters)===0): ?>
 <?php else: ?>
     <label for="size"><h6>Diameter</h6> </label><br/>
     <?php $__currentLoopData = $diameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$diameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
         <input type="radio" id="test_<?php echo $key; ?>" name="diameter" checked>
         <label class="ab_custom_field" for="test_<?php echo $key; ?>"><?php echo e($diameter); ?></label>
<?php else: ?>
<input type="radio" id="test_<?php echo $key; ?>" name="diameter">
         <label class="ab_custom_field" for="test_<?php echo $key; ?>"><?php echo e($diameter); ?></label>
<?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php endif; ?>
 <!-- Diameters check End -->
 <!-- For FocalLength Checkout -->

 <?php if(count($focal_lengths)===0): ?>
 <?php else: ?>
    <br/>
     <label for="size"><h6>Focal Length</h6> </label><br/>
     <?php $__currentLoopData = $focal_lengths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$focallength): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <?php if($key === 0): ?>
         <input type="radio" id="f_length_<?php echo $key; ?>" name="focal_length" checked>
         <label class="ab_custom_field_f_length" for="f_length_<?php echo $key; ?>"><?php echo e($focallength); ?></label>
<?php else: ?>
<input type="radio" id="f_length_<?php echo $key; ?>" name="focal_length">
<label class="ab_custom_field_f_length" for="f_length_<?php echo $key; ?>"><?php echo e($focallength); ?></label>
<?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php endif; ?>
 <!-- FocalLength check End -->
 <!-- For Power Model Checkout -->

 <?php if(count($powerModels)===0): ?>
 <?php else: ?>
    <br/>
     <label for="size"><h6>Power Model</h6> </label><br/>
     <?php $__currentLoopData = $powerModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$powerModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
         <input type="radio" id="power_model<?php echo $key; ?>" name="power_model" checked>
         <label class="ab_custom_fieldpower_model" for="power_model<?php echo $key; ?>"><?php echo e($powerModel); ?></label>
<?php else: ?>
<input type="radio" id="power_model<?php echo $key; ?>" name="power_model">
<label class="ab_custom_fieldpower_model" for="power_model<?php echo $key; ?>"><?php echo e($powerModel); ?></label>
<?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php endif; ?>
 <!-- Power Model check End -->
<!-- For Voltage Checkout -->
<?php if(count($voltages)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Voltage</h6> </label><br/>
<?php $__currentLoopData = $voltages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$voltage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key == 0): ?>
    <input type="radio" id="voltage<?php echo $key; ?>" name="voltage" checked>
    <label class="ab_custom_fieldvoltage" for="voltage<?php echo $key; ?>"><?php echo e($voltage); ?></label>
<?php else: ?>
<input type="radio" id="voltage<?php echo $key; ?>" name="voltage">
    <label class="ab_custom_fieldvoltage" for="voltage<?php echo $key; ?>"><?php echo e($voltage); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- Voltage check End -->
<!-- For Set Checkout -->
<?php if(count($set_words)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Set</h6> </label><br/>
<?php $__currentLoopData = $set_words; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$set_word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="set_word<?php echo $key; ?>" name="set_word" checked>
    <label class="ab_custom_fieldset_word" for="set_word<?php echo $key; ?>"><?php echo e($set_word); ?></label>
<?php else: ?>
<input type="radio" id="set_word<?php echo $key; ?>" name="set_word">
    <label class="ab_custom_fieldset_word" for="set_word<?php echo $key; ?>"><?php echo e($set_word); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- Set check End -->
<!-- For Size Checkout -->
<?php if(count($sizes)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Size</h6> </label><br/>
<?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="size<?php echo $key; ?>" name="size" checked>
    <label class="ab_custom_fieldsize" for="size<?php echo $key; ?>"><?php echo e($size); ?></label>
<?php else: ?>
<input type="radio" id="size<?php echo $key; ?>" name="size">
    <label class="ab_custom_fieldsize" for="size<?php echo $key; ?>"><?php echo e($size); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- Size check End -->
<!-- For working_areas Checkout -->
<?php if(count($working_areas)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Working Area</h6> </label><br/>
<?php $__currentLoopData = $working_areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$working_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="working_area<?php echo $key; ?>" name="working_area" checked>
    <label class="ab_custom_fieldworking_area" for="working_area<?php echo $key; ?>"><?php echo e($working_area); ?></label>
<?php else: ?>
<input type="radio" id="working_area<?php echo $key; ?>" name="working_area">
    <label class="ab_custom_fieldworking_area" for="working_area<?php echo $key; ?>"><?php echo e($working_area); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- working_areas check End -->
<!-- For bone_diameterss Checkout -->
<?php if(count($bone_diameterss)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Bone Diameter</h6> </label><br/>
<?php $__currentLoopData = $bone_diameterss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bone_diameters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
<input type="radio" id="bone_diameters<?php echo $key; ?>" name="bone_diameters" checked>
    <label class="ab_custom_fieldbone_diameters" for="bone_diameters<?php echo $key; ?>"><?php echo e($bone_diameters); ?></label>
<?php else: ?>
<input type="radio" id="bone_diameters<?php echo $key; ?>" name="bone_diameters">
    <label class="ab_custom_fieldbone_diameters" for="bone_diameters<?php echo $key; ?>"><?php echo e($bone_diameters); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- bone_diameterss check End -->
<!-- For models Checkout -->
<?php if(count($models)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Model</h6> </label><br/>
<?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="model<?php echo $key; ?>" name="model" checked>
    <label class="ab_custom_fieldmodel" for="model<?php echo $key; ?>"><?php echo e($model); ?></label>
<?php else: ?>
<input type="radio" id="model<?php echo $key; ?>" name="model">
    <label class="ab_custom_fieldmodel" for="model<?php echo $key; ?>"><?php echo e($model); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- models check End -->
<!-- For output_voltages Checkout -->
<?php if(count($output_voltages)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Output Voltage</h6> </label><br/>
<?php $__currentLoopData = $output_voltages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$output_voltage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="output_voltage<?php echo $key; ?>" name="output_voltage" checked>
    <label class="ab_custom_fieldoutput_voltage" for="output_voltage<?php echo $key; ?>"><?php echo e($output_voltage); ?></label>
<?php else: ?>
<input type="radio" id="output_voltage<?php echo $key; ?>" name="output_voltage">
    <label class="ab_custom_fieldoutput_voltage" for="output_voltage<?php echo $key; ?>"><?php echo e($output_voltage); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- output_voltages check End -->
<!-- For model_numbers Checkout -->
<?php if(count($model_numbers)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Model Numbers</h6> </label><br/>
<?php $__currentLoopData = $model_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$model_number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="model_number<?php echo $key; ?>" name="model_number" checked>
    <label class="ab_custom_fieldmodel_number" for="model_number<?php echo $key; ?>"><?php echo e($model_number); ?></label>
<?php else: ?>
<input type="radio" id="model_number<?php echo $key; ?>" name="model_number">
    <label class="ab_custom_fieldmodel_number" for="model_number<?php echo $key; ?>"><?php echo e($model_number); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- model_numbers check End -->
<!-- For types Checkout -->
<?php if(count($types)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Types</h6> </label><br/>
<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="type<?php echo $key; ?>" name="type" checked>
    <label class="ab_custom_fieldtype" for="type<?php echo $key; ?>"><?php echo e($type); ?></label>
<?php else: ?>
<input type="radio" id="type<?php echo $key; ?>" name="type">
    <label class="ab_custom_fieldtype" for="type<?php echo $key; ?>"><?php echo e($type); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- types check End -->
<!-- For calibers Checkout -->
<?php if(count($calibers)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Caliber</h6> </label><br/>
<?php $__currentLoopData = $calibers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$caliber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="caliber<?php echo $key; ?>" name="caliber" checked>
    <label class="ab_custom_fieldcaliber" for="caliber<?php echo $key; ?>"><?php echo e($caliber); ?></label>
<?php else: ?>
<input type="radio" id="caliber<?php echo $key; ?>" name="caliber">
    <label class="ab_custom_fieldcaliber" for="caliber<?php echo $key; ?>"><?php echo e($caliber); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- calibers check End -->
<!-- For calibers Checkout -->
<?php if(count($sub_strate_sizes)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>sub strate sizes</h6> </label><br/>
<?php $__currentLoopData = $sub_strate_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sub_strate_size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="sub_strate_size<?php echo $key; ?>" name="sub_strate_size" checked>
    <label class="ab_custom_fieldsub_strate_size" for="sub_strate_size<?php echo $key; ?>"><?php echo e($sub_strate_size); ?></label>
<?php else: ?>
<input type="radio" id="sub_strate_size<?php echo $key; ?>" name="sub_strate_size">
    <label class="ab_custom_fieldsub_strate_size" for="sub_strate_size<?php echo $key; ?>"><?php echo e($sub_strate_size); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- calibers check End -->
<!-- For wavelengths Checkout -->
<?php if(count($wavelengths)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>WaveLength</h6> </label><br/>
<?php $__currentLoopData = $wavelengths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$wavelength): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0 ): ?>
    <input type="radio" id="wavelength<?php echo $key; ?>" name="wavelength" checked>
    <label class="ab_custom_fieldwavelength" for="wavelength<?php echo $key; ?>"><?php echo e($wavelength); ?></label>
<?php else: ?>
<input type="radio" id="wavelength<?php echo $key; ?>" name="wavelength">
    <label class="ab_custom_fieldwavelength" for="wavelength<?php echo $key; ?>"><?php echo e($wavelength); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- wavelengths check End -->
<!-- For materials Checkout -->
<?php if(count($materials)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Materials</h6> </label><br/>
<?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="material<?php echo $key; ?>" name="material" checked>
    <label class="ab_custom_fieldmaterial" for="material<?php echo $key; ?>"><?php echo e($material); ?></label>
<?php else: ?>
<input type="radio" id="material<?php echo $key; ?>" name="material">
    <label class="ab_custom_fieldmaterial" for="material<?php echo $key; ?>"><?php echo e($material); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- materials check End -->
<!-- For styles Checkout -->
<?php if(count($styles)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Style</h6> </label><br/>
<?php $__currentLoopData = $styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="style<?php echo $key; ?>" name="style" checked>
    <label class="ab_custom_fieldstyle" for="style<?php echo $key; ?>"><?php echo e($style); ?></label>
<?php else: ?>
<input type="radio" id="style<?php echo $key; ?>" name="style">
    <label class="ab_custom_fieldstyle" for="style<?php echo $key; ?>"><?php echo e($style); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- style check End -->
<!-- For colors Checkout -->
<?php if(count($colors)===0): ?>
<?php else: ?>
<br/>
<label for="size"><h6>Colors</h6> </label><br/>
<?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($key === 0): ?>
    <input type="radio" id="color<?php echo $key; ?>" name="color" checked>
    <label class="ab_custom_fieldcolor" for="color<?php echo $key; ?>"><?php echo e($color); ?></label>
<?php else: ?>
<input type="radio" id="color<?php echo $key; ?>" name="color">
    <label class="ab_custom_fieldcolor" for="color<?php echo $key; ?>"><?php echo e($color); ?></label>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- colors check End -->
<?php /**PATH C:\xampp\htdocs\LaserCutLaravel\V2\resources\views/detailcheckcondition.blade.php ENDPATH**/ ?>