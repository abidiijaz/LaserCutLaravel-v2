<?php $__env->startSection('mytitle','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<style>
    select option {
    background: #626263;
    color: #fff;
    }
    .abi-custom-subcate{
        background: rgba(0, 0, 0, 0.3);
    }
</style>
<div class="section-body mt-3">
            <div class="container-fluid">
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-md-flex justify-content-between mb-2">
                                    <ul class="nav nav-tabs b-none">
                                        <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#list"><i class="fa fa-list-ul"></i>Product Category List</a></li>
                                        <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#addnew"><i class="fa fa-plus"></i> Add New Category</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section-body">
            <div class="container-fluid">
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="list" role="tabpanel">
                    <div class="row clearfix">
                    <div class="col-12 col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">View All Product Categories</h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display" style="width:100%">
                                        <thead>
                                            <tr>
                                                <!--<th>#</th>-->
                                                <th>Name</th>
                                                <th>Image</th>
                                                <th>Sub-Category</th>
                                                <th>Slug</th>
                                                <th>Menu Section</th>
                                                <th>Description</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-capitalize"><?php echo e($category->name); ?></td>
                                                <td>
                                                    <?php if($category->image == ''): ?>
                                                    Image Not Found!
                                                    <?php else: ?>
                                                    <img src="<?php echo e(asset('ab_admin/category/'.$category->image)); ?>" width="80" style="border: 1px solid lightgray; padding:5px;" alt="Avatar">
                                                    <?php endif; ?>
                                                    </td>
                                                    <td class="text-capitalize">
                                                        <?php if(empty($category->parentcategory)): ?>
                                                        Parent
                                                        <?php else: ?>
                                                        <?php echo e($category->parentcategory->name); ?>

                                                        <?php endif; ?>
                                                      
                                                </td>
                                                <td><?php echo e($category->keyword); ?></td>
                                                <td><?php if($category->section_id == 1): ?>
                                                    Machine
                                                    <?php else: ?>
                                                    Acceessories
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-capitalize"><?php echo e($category->description); ?></td>
                                                <td>
                                                    <label class="custom-switch m-0">
                                                        <input type="checkbox" value="0" <?php echo e(($category->status == 1?'checked':'')); ?> class="custom-switch-input admin-change-status-user" data-id="" data-toggle="toggle" data-onstyle="outline-success" >
                                                        <span class="custom-switch-indicator"></span>
                                                    </label>
                                                </td>
                                                <td class="d-flex">
                                                    <form action="/admin/edit-category" method="post" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id" value="<?php echo e($category->id); ?>">
                                                        <button class="btn btn-primary btn-sm">Edit</button>
                                                    </form>
                                                    |  <form action="/admin/delete-category" method="post" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id" value="<?php echo e($category->id); ?>">
                                                        <button class="btn btn-danger btn-sm">Del</button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <!--<th>#</th>-->
                                                <th>Name</th>
                                                <th>Image</th>
                                                <th>Sub-Category</th>
                                                <th>Slug</th>
                                                <th>Menu Section</th>
                                                <th>Description</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="tab-pane fade" id="addnew" role="tabpanel">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title">Add Category</h3>

                                    </div>
                                    <form class="card-body" method="post" action="<?php echo e(url('/admin/add-category')); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row clearfix">
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group">
                                                    <label>Name</label>
                                                    <input type="text" name="name" class="form-control" placeholder="Enter Category Name" required>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group">
                                                    <label>Keyword</label>
                                                    <input type="text" name="Keyword" class="form-control" placeholder="category Keyword" required>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <label>Select category</label>
                                                <select class="form-control" name="parent_category" class="selectpicker">
                                                    <option value="0">== ROOT ==</option>
                                                    <?php $__currentLoopData = $parent_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($category->parent_id == 0): ?>
                                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                        <?php endif; ?>
                                                        <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option class="abi-custom-subcate" value="<?php echo e($sub_cate->id); ?>">&nbsp;&nbsp;&nbsp; &#8594; <?php echo e($sub_cate->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <label>Select Category Type</label>
                                                <select class="form-control" name="acceesory">
                                                    <option value="1">Machine</option>
                                                    <option value="2">Acceesories</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group">
                                                    <label>Image</label>
                                                    <input type="file" name="image" class="form-control" placeholder="image">
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <label>Status  </label>
                                                    <div class="form-group pt-2">
                                                        <label class="custom-switch m-0">
                                                            <input type="checkbox" name="status" class="custom-switch-input" data-id=""  >
                                                            <span class="custom-switch-indicator"></span>
                                                        </label>
                                                    </div>
                                                </div>
                                            <div class="col-md-12 col-sm-12">
                                                <div class="form-group">
                                                    <label>Description</label>
                                                    <div class="input-group mb-3">
                                                        <textarea class="form-control" name="description"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                                <button type="submit" class="btn btn-outline-secondary">Cancel</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
        <script>
            $(document).ready(function(){
                   $('#example').DataTable({
                       scrollX: true,
                       responsive: true
                   });
               });
       </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaserCutLaravel\V2\resources\views/admin/category/index.blade.php ENDPATH**/ ?>