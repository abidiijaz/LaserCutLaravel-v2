<?php $__env->startSection('title',$category->name); ?>
<?php $__env->startSection('meta_description',$category->description); ?>
<?php $__env->startSection('meta_keyword',$category->keyword); ?>
<?php $__env->startSection('content'); ?>
<main class="main">
    <div class="page-header text-center" style="background-image: url('assets/images/page-header-bg.jpg')">
        <div class="container">
            <h1 class="page-title">Aqua CNC Solutions <span>Shop</span></h1>
        </div><!-- End .container -->
    </div><!-- End .page-header -->
    <nav aria-label="breadcrumb" class="breadcrumb-nav mb-2">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Shop</a></li>
                <?php 
                    $inputString = Request::getRequestUri();
                    
                    $outputString = preg_replace('/\/shop\//', '', $inputString);
                    $withoutQueryString = strtok($outputString, '?');
                ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($withoutQueryString); ?></li>
            </ol>
        </div><!-- End .container -->
    </nav><!-- End .breadcrumb-nav -->

    <div class="page-content">
        <div class="container">
            <div class="row">
                <?php if(count($products)): ?>
                    <div class="col-lg-9">
                    <div class="toolbox">
                        <div class="toolbox-left">
                            <div class="toolbox-info">
                                <?php
                                    $total = $products->total();
                                    $currentPage = $products->currentPage();
                                    $perPage = $products->perPage();
                                    
                                    $from = ($currentPage - 1) * $perPage + 1;
                                    $to = min($currentPage * $perPage, $total);
                                ?>
                                Showing <span><?php echo e($from); ?> to <?php echo e($to); ?> of <?php echo e($total); ?></span> Products
                            </div><!-- End .toolbox-info -->
                        </div><!-- End .toolbox-left -->
                    </div><!-- End .toolbox -->

                    <div class="products mb-3">
                        <div class="row justify-content-center">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7 text-center">
                                    <figure class="product-media">
                                        
                                        <a href="/detail-product/<?php echo e($product->id); ?>">
                                            <?php $cus_image = json_decode($product->image); ?>
                                            <img src="<?php echo e(asset('ab_admin/product/'.$cus_image[0])); ?>" alt="<?php echo e($product->title); ?>" class="product-image">
                                        </a>

                                        <div class="product-action-vertical">
                                            
                                            <!--<a href="popup/quickView.html" class="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>-->
                                            
                                        </div><!-- End .product-action-vertical -->

                                        <div class="product-action">
                                            <a href="#" onclick="AddToCart(<?php echo e($product->id); ?>)" class="btn-product btn-cart"><span>add to cart</span></a>
                                        </div><!-- End .product-action -->
                                    </figure><!-- End .product-media -->

                                    <div class="product-body">
                                        <div class="product-cat">
                                            <a href="#"><?php echo e($product->getCategory->name); ?></a>
                                        </div><!-- End .product-cat -->
                                        <h3 class="product-title"><a href="/detail-product/<?php echo e($product->id); ?>"><?php echo e($product->title); ?></a></h3><!-- End .product-title -->
                                        <div class="product-price">
                                            $<?php echo e($product->price); ?>

                                        </div><!-- End .product-price -->
                                        
                                    </div><!-- End .product-body -->
                                </div><!-- End .product -->
                            </div><!-- End .col-sm-6 col-lg-4 col-xl-3 -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            

                          
                        </div><!-- End .row -->
                    </div><!-- End .products -->
                    <?php if($products->hasPages()): ?>
                        <div class="pagination-wrapper">
                             <?php echo e($products->links()); ?>

                        </div>
                    <?php endif; ?>
                    
                </div><!-- End .col-lg-9 -->
                <?php else: ?>
                <h2 class="m-auto">We Are Sorry, Record Not Found!</h2>
                <?php endif; ?>
                <aside class="col-lg-3 order-lg-first">
                    <div class="sidebar sidebar-shop">
                        <div class="widget widget-clean">
                            <label>Filters:</label>
                            <a href="#" class="sidebar-filter-clear">Clean All</a>
                        </div><!-- End .widget widget-clean -->

                        <div class="widget widget-collapsible">
                            <h3 class="widget-title">
                                <a data-toggle="collapse" href="#widget-1" role="button" aria-expanded="true" aria-controls="widget-1">
                                   Machine Category
                                </a>
                            </h3><!-- End .widget-title -->

                            <div class="collapse show" id="widget-1">
                                <div class="widget-body">
                                    <div class="filter-items filter-items-count">
                                        <div class="filter-item">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" id="cat-1">
                                                <label class="custom-control-label" for="cat-1">CR Series</label>
                                            </div><!-- End .custom-checkbox -->
                                            <span class="item-count">3</span>
                                        </div><!-- End .filter-item -->
                                    </div><!-- End .filter-items -->
                                </div><!-- End .widget-body -->
                            </div><!-- End .collapse -->
                        </div><!-- End .widget -->
                        <div class="widget widget-collapsible">
                            <h3 class="widget-title">
                                <a data-toggle="collapse" href="#widget-2" role="button" aria-expanded="false" aria-controls="widget-2">
                                   Accessories
                                </a>
                            </h3><!-- End .widget-title -->

                            <div class="collapse" id="widget-2">
                                <div class="widget-body">
                                    <div class="filter-items filter-items-count">
                                        <div class="filter-item">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" id="cat-1">
                                                <label class="custom-control-label" for="cat-1">CR Series</label>
                                            </div><!-- End .custom-checkbox -->
                                            <span class="item-count">3</span>
                                        </div><!-- End .filter-item -->
                                    </div><!-- End .filter-items -->
                                </div><!-- End .widget-body -->
                            </div><!-- End .collapse -->
                        </div><!-- End .widget -->
                        
                    </div><!-- End .sidebar sidebar-shop -->
                </aside><!-- End .col-lg-3 -->
            </div><!-- End .row -->
        </div><!-- End .container -->
    </div><!-- End .page-content -->
</main><!-- End .main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.mainapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaserCutLaravel\V2\resources\views/shop.blade.php ENDPATH**/ ?>