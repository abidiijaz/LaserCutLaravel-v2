<?php if($order->order_status == 0 ): ?>
<button class="ab_OrderAccepted" disabled>Order Accepted</button>
<?php elseif($order->order_status == 1): ?>
<button class="ab_InProcess" disabled>In Processing</button>
<?php elseif($order->order_status == 2): ?>
<button class="ab_Deliver" disabled>Deliver</button>
<?php elseif($order->order_status == 3): ?>
<button class="ab_Delivered" disabled>Delivered</button>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\LaserCutLaravel\V2\resources\views/components/admin/order_status.blade.php ENDPATH**/ ?>